
/* usability enhancement ideas */
document.getElementById('firstname').focus();
